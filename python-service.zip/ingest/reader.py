"""Low-latency frame readers for the inference tap.

Two implementations with the same interface, both yielding (wall_time, frame):

* FfmpegReader: ffmpeg subprocess writing raw frames to a pipe. Isolates decoder
  crashes from the detector process.
* PyAVReader: in-process decode with PyAV; one fewer copy.

Low-latency settings (measured in bench/infra_bench.py):
  -fflags nobuffer -flags low_delay   no demuxer buffering, decoder emits at once
  -probesize 32 -analyzeduration 0    start from the SDP, do not probe seconds of video
  -threads 1                          frame-threaded H.264 decoding holds frames back
  -flush_packets 1                    do not let the pipe buffer collect frames
"""
from __future__ import annotations

import subprocess
import time
from typing import Iterator

import numpy as np

LOW_LATENCY_INPUT = ["-fflags", "nobuffer", "-flags", "low_delay",
                     "-probesize", "32", "-analyzeduration", "0", "-threads", "1"]


class FfmpegReader:
    def __init__(self, url: str, width: int, height: int, transport: str = "tcp",
                 low_latency: bool = True, single_thread: bool = True, vf: str | None = None,
                 pix_fmt: str = "gray", timeout_s: float = 5.0):
        self.w, self.h = width, height
        self.ch = 1 if pix_fmt == "gray" else 3
        flags = LOW_LATENCY_INPUT if low_latency else []
        if low_latency and not single_thread:
            flags = flags[:-2]
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
               "-rtsp_transport", transport, "-timeout", str(int(timeout_s * 1e6)), *flags,
               "-i", url, "-map", "0:v"]
        if vf:
            cmd += ["-vf", vf]
        cmd += ["-pix_fmt", pix_fmt, "-f", "rawvideo", "-fps_mode", "passthrough",
                "-flush_packets", "1", "pipe:1"]
        self.cmd = cmd
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                     stdin=subprocess.DEVNULL, bufsize=0)

    def frames(self) -> Iterator[tuple[float, np.ndarray]]:
        n = self.w * self.h * self.ch
        buf = bytearray(n)
        view = memoryview(buf)
        while True:
            got = 0
            while got < n:
                r = self.proc.stdout.readinto(view[got:])
                if not r:
                    return
                got += r
            shape = (self.h, self.w) if self.ch == 1 else (self.h, self.w, 3)
            yield time.time(), np.frombuffer(bytes(buf), np.uint8).reshape(shape)

    def close(self) -> None:
        if self.proc.poll() is None:
            self.proc.kill()
            self.proc.wait()


class PyAVReader:
    def __init__(self, url: str, transport: str = "tcp", low_latency: bool = True,
                 crop: tuple[int, int, int, int] | None = None):
        import av  # imported lazily so the ffmpeg path has no PyAV dependency
        opts = {"rtsp_transport": transport, "timeout": "5000000"}
        if low_latency:
            opts.update({"fflags": "nobuffer", "flags": "low_delay",
                         "probesize": "32", "analyzeduration": "0"})
        self.c = av.open(url, options=opts, timeout=10)
        self.s = self.c.streams.video[0]
        if low_latency:
            self.s.codec_context.thread_count = 1
            try:
                self.s.codec_context.flags |= av.codec.context.Flags.low_delay
            except AttributeError:
                self.s.codec_context.flags |= av.codec.context.Flags.LOW_DELAY
        self.crop = crop

    def frames(self) -> Iterator[tuple[float, np.ndarray]]:
        for fr in self.c.decode(self.s):
            t = time.time()
            y = fr.to_ndarray(format="gray")
            if self.crop:
                x, yy, w, h = self.crop
                y = y[yy:yy + h, x:x + w]
            yield t, y

    def close(self) -> None:
        self.c.close()
