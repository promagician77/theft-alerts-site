#!/usr/bin/env python3
"""Live loop: camera substream -> detector -> pose -> tracker -> event engine -> till alert.

    python -m detect.run_live --url rtsp://relay:8554/aisle3_sub --camera aisle3 \
        --detector models/yolox_s.onnx --pose models/rtmpose-m.onnx \
        --zones config/zones.aisle3.json --model web/public/data/model.json \
        --alerts http://localhost:8080 --recordings recordings/segments.db

Status: the reader, YOLOX pre/post-processing, the tracker and the engine are tested in
this kit (tests/test_live_parts.py, detect/test_parity.py). The RTMPose adapter follows
the published SimCC decoding but was not run here: the pose weights download from
OpenMMLab, which this build environment could not reach. Until a product detector is
fine-tuned on store footage, COCO classes stand in (bottle, cup, cell phone, handbag,
backpack).
"""
from __future__ import annotations

import argparse
import json
import sys
import threading
import time
import urllib.request
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from detect.engine import Engine  # noqa: E402

COCO_TO_CLASS = {0: "person", 24: "bag", 26: "bag", 39: "product", 41: "product", 46: "product", 47: "product",
                 67: "phone", 73: "product"}


# ------------------------------------------------------------------ YOLOX (Apache-2.0)
def letterbox(img: np.ndarray, size: int) -> tuple[np.ndarray, float]:
    h, w = img.shape[:2]
    r = min(size / h, size / w)
    nh, nw = int(round(h * r)), int(round(w * r))
    ys = (np.arange(nh) / r).astype(int).clip(0, h - 1)
    xs = (np.arange(nw) / r).astype(int).clip(0, w - 1)
    out = np.full((size, size, 3), 114, np.uint8)
    out[:nh, :nw] = img[ys][:, xs]
    return out, r


def yolox_decode(pred: np.ndarray, size: int, strides=(8, 16, 32)) -> np.ndarray:
    """Turn raw YOLOX grid outputs (N, 85) into (cx, cy, w, h, obj, cls...) in input pixels."""
    grids, exp = [], []
    for s in strides:
        g = size // s
        yv, xv = np.meshgrid(np.arange(g), np.arange(g), indexing="ij")
        grids.append(np.stack((xv, yv), 2).reshape(-1, 2))
        exp.append(np.full((g * g, 1), s))
    grids, exp = np.concatenate(grids), np.concatenate(exp)
    out = pred.copy()
    out[:, :2] = (out[:, :2] + grids) * exp
    out[:, 2:4] = np.exp(out[:, 2:4]) * exp
    return out


def nms(boxes: np.ndarray, scores: np.ndarray, thr: float = 0.45) -> list[int]:
    x1, y1, x2, y2 = boxes.T
    areas = (x2 - x1) * (y2 - y1)
    order = scores.argsort()[::-1]
    keep = []
    while order.size:
        i = order[0]
        keep.append(int(i))
        xx1 = np.maximum(x1[i], x1[order[1:]]); yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]]); yy2 = np.minimum(y2[i], y2[order[1:]])
        inter = np.maximum(0, xx2 - xx1) * np.maximum(0, yy2 - yy1)
        iou = inter / (areas[i] + areas[order[1:]] - inter + 1e-9)
        order = order[1:][iou <= thr]
    return keep


def yolox_postprocess(raw: np.ndarray, size: int, ratio: float, conf: float = 0.35) -> list[dict]:
    p = yolox_decode(raw[0], size)
    cls = p[:, 5:].argmax(1)
    score = p[:, 4] * p[np.arange(len(p)), 5 + cls]
    m = score >= conf
    if not m.any():
        return []
    p, cls, score = p[m], cls[m], score[m]
    xyxy = np.stack([p[:, 0] - p[:, 2] / 2, p[:, 1] - p[:, 3] / 2, p[:, 0] + p[:, 2] / 2, p[:, 1] + p[:, 3] / 2], 1) / ratio
    out = []
    for c in np.unique(cls):
        idx = np.where(cls == c)[0]
        for k in nms(xyxy[idx], score[idx]):
            i = idx[k]
            name = COCO_TO_CLASS.get(int(c))
            if name:
                x1, y1, x2, y2 = xyxy[i].tolist()
                out.append({"cls": name, "conf": float(score[i]), "box": {"x": x1, "y": y1, "w": x2 - x1, "h": y2 - y1}})
    return out


class Yolox:
    def __init__(self, path: str, threads: int = 2):
        import onnxruntime as ort
        so = ort.SessionOptions()
        so.intra_op_num_threads = threads
        self.s = ort.InferenceSession(path, so, providers=ort.get_available_providers())
        self.inp = self.s.get_inputs()[0]
        self.size = int(self.inp.shape[2])

    def __call__(self, bgr: np.ndarray) -> list[dict]:
        img, r = letterbox(bgr, self.size)
        x = img.transpose(2, 0, 1)[None].astype(np.float32)
        return yolox_postprocess(self.s.run(None, {self.inp.name: x})[0], self.size, r)


# ------------------------------------------------------------------ RTMPose (Apache-2.0), not run here
class RTMPose:
    """Top-down pose on each person box. SimCC decoding as published with RTMPose."""

    MEAN = np.array([123.675, 116.28, 103.53], np.float32)
    STD = np.array([58.395, 57.12, 57.375], np.float32)

    def __init__(self, path: str):
        import onnxruntime as ort
        self.s = ort.InferenceSession(path, providers=ort.get_available_providers())
        self.inp = self.s.get_inputs()[0]
        self.h, self.w = int(self.inp.shape[2]), int(self.inp.shape[3])

    def __call__(self, bgr: np.ndarray, box: dict) -> list[float]:
        cx, cy = box["x"] + box["w"] / 2, box["y"] + box["h"] / 2
        bw, bh = box["w"] * 1.25, box["h"] * 1.25
        if bw / bh > self.w / self.h:
            bh = bw * self.h / self.w
        else:
            bw = bh * self.w / self.h
        xs = np.clip((cx - bw / 2 + (np.arange(self.w) + 0.5) * bw / self.w).astype(int), 0, bgr.shape[1] - 1)
        ys = np.clip((cy - bh / 2 + (np.arange(self.h) + 0.5) * bh / self.h).astype(int), 0, bgr.shape[0] - 1)
        crop = bgr[ys][:, xs][:, :, ::-1].astype(np.float32)
        x = ((crop - self.MEAN) / self.STD).transpose(2, 0, 1)[None]
        sx, sy = self.s.run(None, {self.inp.name: x})
        kx = sx[0].argmax(1) / (sx.shape[2] / self.w)
        ky = sy[0].argmax(1) / (sy.shape[2] / self.h)
        conf = np.minimum(sx[0].max(1), sy[0].max(1))
        kp = []
        for i in range(17):
            kp += [cx - bw / 2 + kx[i] * bw / self.w, cy - bh / 2 + ky[i] * bh / self.h, float(min(1.0, conf[i]))]
        return kp


# ------------------------------------------------------------------ tracker
class IouTracker:
    """Greedy IoU matching of person boxes; ids survive short gaps."""

    def __init__(self, iou: float = 0.3, max_age_s: float = 1.0):
        self.iou, self.max_age = iou, max_age_s
        self.tracks: dict[int, tuple[dict, float]] = {}
        self.next_id = 1

    @staticmethod
    def _iou(a: dict, b: dict) -> float:
        x1, y1 = max(a["x"], b["x"]), max(a["y"], b["y"])
        x2, y2 = min(a["x"] + a["w"], b["x"] + b["w"]), min(a["y"] + a["h"], b["y"] + b["h"])
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        return inter / (a["w"] * a["h"] + b["w"] * b["h"] - inter + 1e-9)

    def update(self, t: float, boxes: list[dict]) -> list[int]:
        self.tracks = {k: v for k, v in self.tracks.items() if t - v[1] <= self.max_age}
        pairs = sorted(((self._iou(b, tb), i, tid) for i, b in enumerate(boxes)
                        for tid, (tb, _) in self.tracks.items()), reverse=True)
        ids: list[int | None] = [None] * len(boxes)
        used: set[int] = set()
        for iou, i, tid in pairs:
            if iou < self.iou or ids[i] is not None or tid in used:
                continue
            ids[i] = tid
            used.add(tid)
        for i, b in enumerate(boxes):
            if ids[i] is None:
                ids[i] = self.next_id
                self.next_id += 1
            self.tracks[ids[i]] = (b, t)
        return [int(x) for x in ids]


# ------------------------------------------------------------------ main loop
def post(url: str, body: dict) -> dict:
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=3) as r:
        return json.loads(r.read())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--camera", required=True)
    ap.add_argument("--detector", required=True)
    ap.add_argument("--pose", required=True)
    ap.add_argument("--zones", required=True, help='{"checkout": box, "shelves": [box...]} in substream pixels')
    ap.add_argument("--model", required=True)
    ap.add_argument("--alerts", default="http://localhost:8080")
    ap.add_argument("--recordings", default=None, help="SegmentIndex db of the main-stream recorder")
    ap.add_argument("--fps", type=float, default=10.0)
    a = ap.parse_args()

    import av
    zones = json.loads(Path(a.zones).read_text())
    mf = json.loads(Path(a.model).read_text())
    eng = Engine(zones["checkout"], zones["shelves"],
                 {"t0Dwell": 1e9, "t1Dwell": 1e9, "t2": mf["threshold"]}, mf["model"])
    det, pose, trk = Yolox(a.detector), RTMPose(a.pose), IouTracker()
    index = None
    if a.recordings:
        from ingest.recorder import SegmentIndex, export_clip
        index = SegmentIndex(a.recordings)
    c = av.open(a.url, options={"rtsp_transport": "tcp", "fflags": "nobuffer", "flags": "low_delay",
                                "probesize": "32", "analyzeduration": "0"})
    s = c.streams.video[0]
    s.codec_context.thread_count = 1
    next_t = 0.0
    for fr in c.decode(s):
        now = time.time()
        if now < next_t:
            continue                      # decode every frame, infer at --fps
        next_t = now + 1 / a.fps
        bgr = fr.to_ndarray(format="bgr24")
        boxes = det(bgr)
        people = [b for b in boxes if b["cls"] == "person"]
        objects = [b for b in boxes if b["cls"] != "person"]
        ids = trk.update(now, [p["box"] for p in people])
        tracks = [{"id": i, "truth": -1, "box": p["box"], "kp": pose(bgr, p["box"])} for i, p in zip(ids, people)]
        out = eng.step({"t": now, "tracks": tracks, "objects": objects})
        for al in out["alerts"]:
            if al["tier"] != 2:
                continue
            feats = next((x["feats"] for x in out["t2"] if x["track"] == al["track"]), [])
            r = post(f"{a.alerts}/events", {"camera": a.camera, "t_event": al["t"], "track": al["track"],
                                            "zone": al["zone"], "score": al["score"], "features": feats})
            if index:
                def cut(aid=r["id"], t=al["t"]):
                    time.sleep(5.5)       # wait for the post-roll to be recorded
                    name = f"{a.camera}_{aid}.mp4"
                    res = export_clip(index, a.camera, t - 10, t + 5, str(Path("alerts/clips") / name))
                    if res["ok"]:
                        post(f"{a.alerts}/events/{aid}/clip", {"url": f"/clips/{name}"})
                threading.Thread(target=cut, daemon=True).start()


if __name__ == "__main__":
    main()
