#!/usr/bin/env python3
"""CPU inference time for the Apache-2.0 YOLOX detectors on this machine (ONNX Runtime)."""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import onnxruntime as ort

ROOT = Path(__file__).resolve().parents[1]


def bench(path: Path, threads: int, runs: int = 30) -> dict:
    so = ort.SessionOptions()
    so.intra_op_num_threads = threads
    so.inter_op_num_threads = 1
    s = ort.InferenceSession(str(path), so, providers=["CPUExecutionProvider"])
    inp = s.get_inputs()[0]
    _, c, h, w = inp.shape
    x = np.random.default_rng(0).random((1, c, h, w), dtype=np.float32) * 255
    out = s.run(None, {inp.name: x})
    for _ in range(3):
        s.run(None, {inp.name: x})
    ts = []
    for _ in range(runs):
        t = time.perf_counter()
        s.run(None, {inp.name: x})
        ts.append((time.perf_counter() - t) * 1000)
    ms = float(np.median(ts))
    return {"model": path.stem, "input": f"{w}x{h}", "threads": threads, "ms_median": round(ms, 1),
            "fps": round(1000 / ms, 1), "output_shape": list(out[0].shape)}


def main() -> None:
    res = []
    for name in ("yolox_nano", "yolox_s"):
        for th in (1, 2):
            r = bench(ROOT / "models" / f"{name}.onnx", th)
            res.append(r)
            print(r, flush=True)
    f = ROOT / "results" / "infra.json"
    allr = json.loads(f.read_text()) if f.exists() else {}
    allr["models"] = {"onnxruntime": ort.__version__, "runs": res,
                      "note": "COCO-pretrained YOLOX (Apache-2.0) on random input; timing only, no accuracy claim"}
    f.write_text(json.dumps(allr, indent=1))


if __name__ == "__main__":
    main()
