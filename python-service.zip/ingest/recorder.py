#!/usr/bin/env python3
"""Crash-safe RTSP recorder.

One supervised ffmpeg process per camera copies the H.264/H.265 stream into short
segments without re-encoding (-c copy). The supervisor:

* restarts ffmpeg with backoff when the camera drops, the network stalls or ffmpeg dies;
* kills ffmpeg if the newest segment stops growing (a half-open TCP session can
  otherwise hang a recorder silently);
* indexes every segment with wall-clock start/end in SQLite so alerts can pull the
  exact clip around an event;
* enforces retention by age and by disk budget.

Segment formats: "fmp4" (fragmented MP4, the default: a crash loses at most one
fragment), "ts" (MPEG-TS) and "mp4" (plain MP4, kept only for comparison: a crash
before the moov box is written loses the whole segment).
"""
from __future__ import annotations

import argparse
import json
import os
import signal
import sqlite3
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CameraConfig:
    name: str
    url: str
    out_dir: str
    fmt: str = "fmp4"            # fmp4 | ts | mp4
    segment_s: int = 10
    rtsp_timeout_s: float = 10.0 # socket I/O timeout handed to ffmpeg
    stall_s: float = 12.0        # watchdog: kill if newest segment stops growing. Longer than a
                                 # short network freeze, which the camera's buffer rides out
    startup_s: float = 20.0      # grace before the first segment of a run must appear
    transport: str = "tcp"
    backoff: list[float] = field(default_factory=lambda: [0.25, 0.5, 1.0])
    healthy_after_s: float = 30.0

    @property
    def ext(self) -> str:
        return "ts" if self.fmt == "ts" else "mp4"


def ffmpeg_cmd(c: CameraConfig, run: int) -> list[str]:
    pattern = str(Path(c.out_dir) / c.name / f"%Y%m%d-%H%M%S_r{run:04d}.{c.ext}")
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
        "-rtsp_transport", c.transport, "-timeout", str(int(c.rtsp_timeout_s * 1e6)),
        "-analyzeduration", "2000000", "-probesize", "1000000",
        "-i", c.url, "-map", "0:v", "-c", "copy",
        "-f", "segment", "-segment_time", str(c.segment_s), "-reset_timestamps", "1",
        "-strftime", "1",
    ]
    # Measured (bench/crash_flush.py): without flushing, a killed ffmpeg loses 1.7-3.9 s of
    # fMP4 or 0.6-2.8 s of MPEG-TS sitting in its write buffer; with per-frame fragments and
    # flush_packets the loss is under 0.2 s. Plain MP4 loses the whole segment.
    if c.fmt == "fmp4":
        cmd += ["-segment_format", "mp4", "-segment_format_options",
                "movflags=+empty_moov+default_base_moof+frag_every_frame:flush_packets=1"]
    elif c.fmt == "ts":
        cmd += ["-segment_format", "mpegts", "-segment_format_options", "flush_packets=1"]
    else:
        cmd += ["-segment_format", "mp4"]
    return cmd + ["-flush_packets", "1", pattern]


class SegmentIndex:
    """Thread-safe SQLite index of recorded segments."""

    def __init__(self, path: str):
        self.lock = threading.Lock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS segments (path TEXT PRIMARY KEY, cam TEXT, run INT,"
            " start REAL, end REAL, dur REAL, bytes INT, ok INT)")
        self.db.commit()

    def opened(self, cam: str, run: int, path: str, start: float) -> None:
        with self.lock:
            self.db.execute("INSERT OR IGNORE INTO segments VALUES (?,?,?,?,NULL,NULL,0,NULL)",
                            (path, cam, run, start))
            self.db.commit()

    def closed(self, path: str, dur: float | None, size: int) -> None:
        with self.lock:
            row = self.db.execute("SELECT start FROM segments WHERE path=?", (path,)).fetchone()
            if not row:
                return
            ok = 1 if dur and dur > 0 else 0
            end = row[0] + (dur or 0.0)
            self.db.execute("UPDATE segments SET end=?, dur=?, bytes=?, ok=? WHERE path=?",
                            (end, dur, size, ok, path))
            self.db.commit()

    def query(self, cam: str, t0: float, t1: float) -> list[tuple[str, float, float]]:
        with self.lock:
            return self.db.execute(
                "SELECT path, start, end FROM segments WHERE cam=? AND ok=1 AND end>? AND start<?"
                " ORDER BY start", (cam, t0, t1)).fetchall()

    def all(self, cam: str | None = None) -> list[tuple]:
        with self.lock:
            q = "SELECT path, cam, run, start, end, dur, bytes, ok FROM segments"
            args: tuple = ()
            if cam:
                q += " WHERE cam=?"
                args = (cam,)
            return self.db.execute(q + " ORDER BY start", args).fetchall()

    def delete(self, path: str) -> None:
        with self.lock:
            self.db.execute("DELETE FROM segments WHERE path=?", (path,))
            self.db.commit()


def probe_duration(path: str) -> float | None:
    """Duration in seconds, or None if the file cannot be parsed."""
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "v:0", "-count_packets",
             "-show_entries", "stream=nb_read_packets,r_frame_rate:format=duration",
             "-of", "json", path], capture_output=True, text=True, timeout=20)
        info = json.loads(out.stdout or "{}")
        d = float(info.get("format", {}).get("duration") or 0)
        if d <= 0:
            st = (info.get("streams") or [{}])[0]
            n = int(st.get("nb_read_packets") or 0)
            num, den = (st.get("r_frame_rate") or "0/1").split("/")
            fps = float(num) / float(den or 1)
            d = n / fps if fps else 0.0
        return d if d > 0 else None
    except Exception:
        return None


class CameraRecorder(threading.Thread):
    def __init__(self, cfg: CameraConfig, index: SegmentIndex, events: list | None = None):
        super().__init__(daemon=True, name=f"rec-{cfg.name}")
        self.cfg = cfg
        self.index = index
        self.events = events if events is not None else []
        self.proc: subprocess.Popen | None = None
        self.run_id = 0
        self.stop_flag = threading.Event()
        self.known: dict[str, float] = {}   # path -> first seen wall time
        self.closed: set[str] = set()
        Path(cfg.out_dir, cfg.name).mkdir(parents=True, exist_ok=True)

    def log(self, kind: str, **kw) -> None:
        self.events.append({"t": time.time(), "cam": self.cfg.name, "kind": kind, **kw})

    def _scan(self) -> tuple[str | None, int]:
        """Register new segments, close finished ones. Returns (newest path, size)."""
        d = Path(self.cfg.out_dir, self.cfg.name)
        # names carry the run id and start time, so name order is time order within a run;
        # modification times are not (a closing segment is touched after the next one opens)
        files = sorted(d.glob(f"*.{self.cfg.ext}"), key=lambda p: (p.stem.split("_r")[-1], p.stem))
        now = time.time()
        for p in files:
            s = str(p)
            if s not in self.known:
                run = int(p.stem.split("_r")[-1]) if "_r" in p.stem else 0
                self.known[s] = now
                self.index.opened(self.cfg.name, run, s, now)
        mine = [p for p in files if p.stem.endswith(f"_r{self.run_id:04d}")]
        newest = str(mine[-1]) if mine else None
        for s in list(self.known):
            if s != newest and s not in self.closed:
                self._close(s)
        return newest, (Path(newest).stat().st_size if newest and Path(newest).exists() else 0)

    def _close(self, s: str) -> None:
        self.closed.add(s)
        size = Path(s).stat().st_size if Path(s).exists() else 0
        self.index.closed(s, probe_duration(s), size)

    def run(self) -> None:
        attempt = 0
        while not self.stop_flag.is_set():
            self.run_id += 1
            started = time.time()
            self.proc = subprocess.Popen(ffmpeg_cmd(self.cfg, self.run_id),
                                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL)
            self.log("start", run=self.run_id, pid=self.proc.pid)
            last_size, last_growth = -1, time.time()
            reason = "exit"
            while not self.stop_flag.is_set():
                if self.proc.poll() is not None:
                    reason = f"exit:{self.proc.returncode}"
                    break
                newest, size = self._scan()
                if size != last_size:
                    last_size, last_growth = size, time.time()
                limit = self.cfg.stall_s if newest and size > 0 else self.cfg.startup_s
                if time.time() - last_growth > limit:
                    reason = "stall" if newest else "no-start"
                    self._terminate()
                    break
                time.sleep(0.25)
            if self.stop_flag.is_set():
                break
            self._scan()
            healthy = time.time() - started > self.cfg.healthy_after_s
            attempt = 0 if healthy else attempt + 1
            wait = self.cfg.backoff[min(max(attempt - 1, 0), len(self.cfg.backoff) - 1)] if attempt else 0.2
            self.log("restart", reason=reason, wait=wait)
            self.stop_flag.wait(wait)
        if self.proc and self.proc.poll() is None:
            self.proc.send_signal(signal.SIGINT)   # lets ffmpeg finalise the open segment
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        time.sleep(0.3)
        self._scan()
        for s in list(self.known):
            if s not in self.closed:
                self._close(s)

    def _terminate(self) -> None:
        """SIGINT first so ffmpeg can close the segment cleanly, then SIGKILL."""
        try:
            self.proc.send_signal(signal.SIGINT)
            self.proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.proc.kill()
            self.proc.wait()

    def stop(self) -> None:
        self.stop_flag.set()


def export_clip(index: SegmentIndex, cam: str, t0: float, t1: float, out: str, margin_s: float = 0.6) -> dict:
    """Cut [t0, t1] (wall clock) into one file without re-encoding.

    With -c copy the cut snaps back to the previous keyframe, so the clip can start
    up to one GOP early. Segment start times come from when the file appeared (polled
    every 0.25 s), so both ends get a small margin.
    """
    t0, t1 = t0 - margin_s, t1 + margin_s
    segs = index.query(cam, t0, t1)
    if not segs:
        return {"ok": False, "reason": "no segments"}
    lst = Path(out).with_suffix(".txt")
    lines = []
    for i, (path, start, end) in enumerate(segs):
        lines.append(f"file '{path}'")
        if i == 0 and t0 > start:
            lines.append(f"inpoint {t0 - start:.3f}")
        if i == len(segs) - 1 and t1 < end:
            lines.append(f"outpoint {t1 - start:.3f}")
    lst.write_text("\n".join(lines) + "\n")
    t = time.time()
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat",
                        "-safe", "0", "-i", str(lst), "-c", "copy", "-movflags", "+faststart", out],
                       capture_output=True, text=True)
    return {"ok": r.returncode == 0, "segments": len(segs), "seconds": round(time.time() - t, 3),
            "path": out, "err": r.stderr[-300:]}


def enforce_retention(index: SegmentIndex, max_bytes: int, max_age_s: float,
                      now: float | None = None) -> list[str]:
    """Delete oldest closed segments beyond the age limit or the disk budget."""
    now = now or time.time()
    rows = [r for r in index.all() if r[4] is not None]
    deleted = []
    total = sum(r[6] or 0 for r in rows)
    for path, _cam, _run, start, _end, _dur, size, _ok in rows:
        if now - start > max_age_s or total > max_bytes:
            try:
                os.remove(path)
            except FileNotFoundError:
                pass
            index.delete(path)
            total -= size or 0
            deleted.append(path)
        else:
            break
    return deleted


def main() -> None:
    ap = argparse.ArgumentParser(description="Crash-safe RTSP recorder")
    ap.add_argument("--config", required=True, help="JSON: {cameras:[...], index, retention}")
    a = ap.parse_args()
    cfg = json.loads(Path(a.config).read_text())
    index = SegmentIndex(cfg.get("index", "segments.db"))
    recs = [CameraRecorder(CameraConfig(**c), index) for c in cfg["cameras"]]
    for r in recs:
        r.start()
    ret = cfg.get("retention", {"max_gb": 500, "max_days": 30})
    stop = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stop.set())
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    while not stop.wait(60):
        enforce_retention(index, int(ret["max_gb"] * 1e9), ret["max_days"] * 86400)
    for r in recs:
        r.stop()
    for r in recs:
        r.join(timeout=10)


if __name__ == "__main__":
    main()
