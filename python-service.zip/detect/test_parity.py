"""Replay the TypeScript engine's frames through the Python engine and require identical output."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from detect.engine import Engine  # noqa: E402


def close(a, b, tol=1e-12) -> bool:
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool):
        return abs(a - b) <= tol * max(1.0, abs(a), abs(b))
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(close(a[k], b[k], tol) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(close(x, y, tol) for x, y in zip(a, b))
    return a == b


def main() -> int:
    data = json.loads((HERE / "parity.json").read_text())
    z = data["zones"]
    total = {"frames": 0, "alerts": 0, "episodes": 0, "t1": 0, "t2": 0, "mismatch": 0, "max_score_diff": 0.0}
    t = time.perf_counter()
    for sess in data["sessions"]:
        eng = Engine(z["checkout"], z["shelves"], data["thr"], data["model"])
        for f, want in zip(sess["frames"], sess["outputs"]):
            got = eng.step(f)
            total["frames"] += 1
            for key in ("alerts", "episodes", "t1", "t2"):
                total[key] += len(want[key])
                if not close(got[key], want[key]):
                    total["mismatch"] += 1
                    if total["mismatch"] <= 3:
                        print("MISMATCH", sess["seed"], f["t"], key, got[key], want[key])
            for g, w in zip(got["t2"], want["t2"]):
                total["max_score_diff"] = max(total["max_score_diff"], abs(g["score"] - w["score"]))
    total["python_ms_per_frame"] = round(1000 * (time.perf_counter() - t) / max(1, total["frames"]), 4)
    print(json.dumps(total))
    (HERE / "parity_result.json").write_text(json.dumps(total, indent=1))
    return 1 if total["mismatch"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
