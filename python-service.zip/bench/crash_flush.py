#!/usr/bin/env python3
"""Crash-loss experiment: SIGKILL ffmpeg recorders mid-segment and count seconds lost before the kill."""
import json, os, signal, subprocess, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from bench.infra_bench import MTX, FPS, camera, decode_indices, kill, mtx_config, spawn, wait_for, RESULTS

OPTS = {
    "fmp4_keyframe_1s": ["-f", "mp4", "-movflags", "+empty_moov+default_base_moof+frag_keyframe", "-frag_duration", "1000000"],
    "fmp4_every_frame": ["-f", "mp4", "-movflags", "+empty_moov+default_base_moof+frag_every_frame"],
    "fmp4_every_frame_flush": ["-f", "mp4", "-movflags", "+empty_moov+default_base_moof+frag_every_frame", "-flush_packets", "1"],
    "mpegts": ["-f", "mpegts"],
    "mpegts_flush": ["-f", "mpegts", "-flush_packets", "1"],
    "mp4_plain": ["-f", "mp4"],
}
work = Path(tempfile.mkdtemp())
srv = spawn([MTX, str(mtx_config(work / "c.yml", 8554, 8000, {"cam1": {"source": "publisher"}}))])
time.sleep(0.5); t0 = time.time(); log = work / "cam.log"
cam = camera("rtsp://127.0.0.1:8554/cam1", t0, log)
wait_for(lambda: log.exists() and log.stat().st_size > 1000, 15); time.sleep(1)
res = {k: [] for k in OPTS}
for trial, hold in enumerate([7.3, 8.1, 9.0, 7.7, 8.6]):
    procs = {}
    for k, o in OPTS.items():
        out = work / f"{k}_{trial}.{'ts' if 'mpegts' in k else 'mp4'}"
        procs[k] = (subprocess.Popen(["ffmpeg", "-hide_banner", "-loglevel", "error", "-rtsp_transport", "tcp",
            "-i", "rtsp://127.0.0.1:8554/cam1", "-map", "0:v", "-c", "copy", *o, str(out)],
            stdin=subprocess.DEVNULL, stderr=subprocess.DEVNULL), out)
    time.sleep(hold)
    t_kill = time.time()
    for p, _ in procs.values(): p.kill()
    for p, _ in procs.values(): p.wait()
    k_kill = (t_kill - t0) * FPS
    for k, (_, out) in procs.items():
        idx, _ = decode_indices(str(out))
        lost = (k_kill - max(idx)) / FPS if idx else hold
        res[k].append(round(lost, 2))
kill(cam); kill(srv)
summary = {k: {"lost_before_kill_s": v, "max_s": max(v)} for k, v in res.items()}
print(json.dumps(summary, indent=1))
f = RESULTS / "infra.json"; allr = json.loads(f.read_text()); allr["crash_flush"] = summary; f.write_text(json.dumps(allr, indent=1))
