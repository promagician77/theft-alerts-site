"""Frame-index barcode.

Each synthetic camera frame carries its index as 32 blocks (24-bit index + 8-bit
check) in the top-left corner. Because the index is burned into the pixels, every
benchmark can count exactly which frames were delivered, recorded or lost, after
H.264 encoding, RTSP transport, recording and decoding.
"""
from __future__ import annotations

import numpy as np

BLOCK = 16          # block size in pixels
NBITS = 32          # 24-bit index + 8-bit check
X0, Y0 = 16, 16     # top-left corner of the code
HI, LO = 235, 16    # luma levels for 1 and 0
CROP = (X0, Y0, NBITS * BLOCK, BLOCK)  # x, y, w, h of the code region


def check8(i: int) -> int:
    return ((i * 2654435761) & 0xFFFFFFFF) >> 24


def word_for(i: int) -> int:
    i &= 0xFFFFFF
    return (i << 8) | check8(i)


def stamp(y_plane: np.ndarray, i: int) -> None:
    """Write index ``i`` into a luma plane (H x W, uint8) in place."""
    w = word_for(i)
    for b in range(NBITS):
        bit = (w >> (NBITS - 1 - b)) & 1
        x = X0 + b * BLOCK
        y_plane[Y0:Y0 + BLOCK, x:x + BLOCK] = HI if bit else LO


_WEIGHTS = (1 << np.arange(NBITS - 1, -1, -1, dtype=np.uint64)).astype(np.uint64)


def read(gray: np.ndarray, x0: int = X0, y0: int = Y0) -> int | None:
    """Decode the index from a luma image. Returns None if the check fails."""
    s, q = BLOCK // 2, BLOCK // 4
    region = gray[y0 + q:y0 + q + s, x0:x0 + NBITS * BLOCK]
    if region.shape != (s, NBITS * BLOCK):
        return None
    vals = region.reshape(s, NBITS, BLOCK)[:, :, q:q + s].mean(axis=(0, 2))
    bits = (vals > 128).astype(np.uint64)
    word = int((bits * _WEIGHTS).sum())
    idx = word >> 8
    return idx if (word & 0xFF) == check8(idx) else None


def read_crop(crop: np.ndarray) -> int | None:
    """Decode from an image already cropped to CROP."""
    return read(crop, 0, 0)
