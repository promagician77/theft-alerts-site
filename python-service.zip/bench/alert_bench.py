#!/usr/bin/env python3
"""Measure detector-to-tablet alert latency through the real alert service.

Starts uvicorn, connects three WebSocket "tablets", posts 600 events, and times each
from just before the HTTP POST to its arrival on every tablet. Also posts feedback and
checks it lands in the database.
"""
from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import numpy as np
import websockets

ROOT = Path(__file__).resolve().parents[1]
PORT = 8765


def post(path: str, body: dict) -> dict:
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", data=json.dumps(body).encode(),
                                 headers={"content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=5) as r:
        return json.loads(r.read())


async def run(n: int = 600, tablets: int = 3) -> dict:
    got: dict[int, list[float]] = {}
    sent: dict[int, float] = {}
    socks = [await websockets.connect(f"ws://127.0.0.1:{PORT}/ws") for _ in range(tablets)]

    async def listen(ws):
        async for msg in ws:
            m = json.loads(msg)
            if m.get("type") == "alert":
                got.setdefault(m["id"], []).append(time.time())

    tasks = [asyncio.create_task(listen(w)) for w in socks]
    loop = asyncio.get_running_loop()
    for i in range(n):
        t = time.time()
        r = await loop.run_in_executor(None, post, "/events",
                                       {"camera": "aisle-3", "t_event": t, "track": i, "zone": "pocket", "score": 0.97})
        sent[r["id"]] = t
        await asyncio.sleep(0.01)
    await asyncio.sleep(1.0)
    fb = await loop.run_in_executor(None, post, "/feedback", {"alert_id": next(iter(sent)), "label": "dismiss"})
    for tk in tasks:
        tk.cancel()
    for w in socks:
        await w.close()
    lat = [(ts - sent[i]) * 1000 for i, arr in got.items() if i in sent for ts in arr]
    delivered = sum(len(v) for k, v in got.items() if k in sent)
    return {"events": n, "tablets": tablets, "deliveries": delivered, "expected": n * tablets,
            "p50_ms": round(float(np.percentile(lat, 50)), 2), "p95_ms": round(float(np.percentile(lat, 95)), 2),
            "p99_ms": round(float(np.percentile(lat, 99)), 2), "max_ms": round(max(lat), 2),
            "feedback_ok": fb.get("ok", False)}


def main() -> None:
    db = ROOT / "alerts" / "alerts.db"
    if db.exists():
        db.unlink()
    srv = subprocess.Popen([sys.executable, "-m", "uvicorn", "alerts.service:app", "--port", str(PORT),
                            "--log-level", "warning"], cwd=ROOT)
    try:
        for _ in range(50):
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{PORT}/alerts", timeout=1)
                break
            except Exception:
                time.sleep(0.2)
        res = asyncio.run(run())
        page = urllib.request.urlopen(f"http://127.0.0.1:{PORT}/cashier", timeout=2).read().decode()
        res["cashier_page_ok"] = "Till alerts" in page
        labelled = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{PORT}/alerts?limit=1000").read())
        res["labels_stored"] = sum(1 for a in labelled if a["label"])
        print(json.dumps(res))
        f = ROOT / "results" / "infra.json"
        allr = json.loads(f.read_text()) if f.exists() else {}
        allr["alerts"] = res
        f.write_text(json.dumps(allr, indent=1))
    finally:
        srv.terminate()
        srv.wait()
        if db.exists():
            db.unlink()


if __name__ == "__main__":
    main()
