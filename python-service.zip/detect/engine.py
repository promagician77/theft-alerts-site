"""Theft-event engine, Python port of web/src/core/engine.ts.

The TypeScript engine is the one benchmarked and shown in the browser; this port is
what runs next to the video pipeline. tests/test_parity.py replays the same frames
through both and requires identical alerts, episodes and candidates, and scores within
1e-12.

Input per frame (from the pose model, the object detector and the tracker):
  {"t": seconds, "tracks": [{"id", "box", "kp": [x, y, conf] * 17, "truth"}],
   "objects": [{"cls", "conf", "box": {"x", "y", "w", "h"}}]}
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

FEATURES = [
    "hold_s", "dwell_s", "product_ratio", "from_shelf", "from_body", "moved_with_hand", "visible_in_zone",
    "zone_pocket", "zone_waist", "zone_chest", "zone_bag", "approach_speed", "wrist_conf", "basket_near",
    "head_scan", "object_conf",
]

KP = dict(nose=0, lsho=5, rsho=6, lwri=9, rwri=10, lhip=11, rhip=12, lank=15, rank=16)

DEFAULT_PARAMS = dict(holdMinS=0.3, vanishMinS=0.5, vanishWindowS=1.6, maxZoneS=4.0, cooldownS=8.0,
                      wristMinConf=0.3, wristHoldS=0.5, matchR=0.65, basketR=0.9, carryGapS=0.7)


def dist(a, b) -> float:
    dx, dy = a[0] - b[0], a[1] - b[1]
    return math.sqrt(dx * dx + dy * dy)


def center(b) -> tuple[float, float]:
    return (b["x"] + b["w"] / 2, b["y"] + b["h"] / 2)


def in_box(v, b, pad: float = 0.0) -> bool:
    return b["x"] - pad <= v[0] <= b["x"] + b["w"] + pad and b["y"] - pad <= v[1] <= b["y"] + b["h"] + pad


def score(model: dict, x: list[float]) -> float:
    z = model["b"]
    for i, v in enumerate(x):
        z += model["w"][i] * ((v - model["mean"][i]) / model["std"][i])
    return 1 / (1 + math.exp(-z))


@dataclass
class Hold:
    start: float
    lastSeen: float
    frames: int
    pos: tuple
    startWrist: tuple
    startBox: tuple
    prod: float = 0.0
    other: float = 0.0
    conf: float = 0.0
    n: int = 0
    prov: str = "none"
    motion: float = -1.0
    atBasket: bool = False
    atShelf: bool = False


@dataclass
class Cand:
    zone: str
    enter: float
    holdS: float
    approach: float
    head: float
    hold: Hold
    basketNear: bool
    lastWrist: tuple
    leave: float | None = None
    seenInZone: int = 0
    framesInZone: int = 0
    wconf: float = 0.0
    unseen: float = 0.0


@dataclass
class HandState:
    wrist: tuple | None = None
    wconf: float = 0.0
    lastGood: float = -1e9
    recent: list = field(default_factory=list)
    zone: str | None = None
    ep: dict | None = None
    h1: Hold | None = None
    h2: Hold | None = None
    c1: Cand | None = None
    c2: Cand | None = None


@dataclass
class TrackState:
    id: int
    truth: int
    last: float
    torso: float = 0.0
    halfW: float = 0.0
    hip: tuple = (0.0, 0.0)
    inTill: bool = False
    head: list = field(default_factory=list)
    hands: list = field(default_factory=lambda: [HandState(), HandState()])
    lastAlert: list = field(default_factory=lambda: [-1e9, -1e9, -1e9])


class Engine:
    def __init__(self, checkout: dict, shelves: list[dict], thr: dict, model: dict | None, **params):
        self.p = {**DEFAULT_PARAMS, **params, "checkout": checkout, "shelves": shelves}
        self.thr = thr
        self.model = model
        self.tracks: dict[int, TrackState] = {}
        self.frame_wrists: list = []

    # ------------------------------------------------------------------ public
    def step(self, f: dict) -> dict:
        out = {"alerts": [], "episodes": [], "t1": [], "t2": []}
        products, carried, bags, baskets = [], [], [], []
        for o in f["objects"]:
            if o["cls"] == "bag":
                bags.append(o)
            elif o["cls"] == "basket":
                baskets.append(o)
            else:
                carried.append(o)
                if o["cls"] == "product" and not any(in_box(center(o["box"]), b) for b in self.p["shelves"]):
                    products.append(o)
        self.frame_wrists = []
        for tr in f["tracks"]:
            for wi in (KP["lwri"], KP["rwri"]):
                if tr["kp"][wi * 3 + 2] >= self.p["wristMinConf"]:
                    self.frame_wrists.append((tr["id"], (tr["kp"][wi * 3], tr["kp"][wi * 3 + 1])))
        for tr in f["tracks"]:
            self._track(f["t"], tr, products, carried, bags, baskets, out)
        for tid in list(self.tracks):
            s = self.tracks[tid]
            if f["t"] - s.last > 2.0:
                for h in s.hands:
                    if h.ep:
                        out["episodes"].append(dict(tier=0, track=s.id, truth=s.truth, zone=h.ep["zone"],
                                                    start=h.ep["start"], end=s.last))
                del self.tracks[tid]
        return out

    # ------------------------------------------------------------------ internals
    def _track(self, t, tr, products, carried, bags, baskets, out) -> None:
        p = self.p
        s = self.tracks.get(tr["id"])
        if s is None:
            s = TrackState(id=tr["id"], truth=tr["truth"], last=t)
            self.tracks[tr["id"]] = s
        prevT = s.last
        s.truth = tr["truth"]
        k = tr["kp"]
        X = lambda i: k[i * 3]
        Y = lambda i: k[i * 3 + 1]
        C = lambda i: k[i * 3 + 2]
        if C(KP["lhip"]) > 0.3 and C(KP["rhip"]) > 0.3 and C(KP["lsho"]) > 0.3 and C(KP["rsho"]) > 0.3:
            hip = ((X(KP["lhip"]) + X(KP["rhip"])) / 2, (Y(KP["lhip"]) + Y(KP["rhip"])) / 2)
            torso = max(4, hip[1] - (Y(KP["lsho"]) + Y(KP["rsho"])) / 2)
            halfW = max(4, abs(X(KP["lsho"]) - X(KP["rsho"])) / 2)
            s.hip = hip
            if s.torso == 0:
                s.torso, s.halfW = torso, halfW
            else:
                s.torso += 0.3 * (torso - s.torso)
                s.halfW += 0.3 * (halfW - s.halfW)
        if s.torso == 0:
            s.last = t
            return
        scale = (s.torso + 2 * s.halfW) / 2
        if C(KP["lank"]) > 0.3 and C(KP["rank"]) > 0.3:
            feet = ((X(KP["lank"]) + X(KP["rank"])) / 2, (Y(KP["lank"]) + Y(KP["rank"])) / 2)
        else:
            feet = (s.hip[0], s.hip[1] + 1.85 * s.torso)
        s.inTill = in_box(feet, p["checkout"])
        dtF = min(0.5, max(1e-3, t - prevT))
        s.last = t
        if C(KP["nose"]) > 0.3 and C(KP["lsho"]) > 0.3 and C(KP["rsho"]) > 0.3:
            s.head.append((t, (X(KP["nose"]) - (X(KP["lsho"]) + X(KP["rsho"])) / 2) / s.halfW))
            while s.head and s.head[0][0] < t - 3:
                s.head.pop(0)
        bag = next((b for b in bags if dist(center(b["box"]), s.hip) < 1.6 * scale), None)

        for hi in (0, 1):
            h = s.hands[hi]
            wi = KP["lwri"] if hi == 0 else KP["rwri"]
            fresh = C(wi) >= p["wristMinConf"]
            if fresh:
                h.wrist, h.wconf, h.lastGood = (X(wi), Y(wi)), C(wi), t
            elif t - h.lastGood > p["wristHoldS"]:
                h.wrist, h.wconf = None, 0
            else:
                h.wconf = C(wi)
            if h.wrist is not None and fresh:
                h.recent.append((t, h.wrist))
                if len(h.recent) > 4:
                    h.recent.pop(0)
            zone = (self._zone(hi, h.wrist, s, bag) if fresh else h.zone) if h.wrist is not None else None
            h.zone = None if s.inTill else zone

            # Tier 0
            if h.zone:
                if not h.ep:
                    h.ep = {"start": t, "zone": h.zone, "fired": False}
                if not h.ep["fired"] and t - h.ep["start"] >= self.thr["t0Dwell"] - 1e-9:
                    h.ep["fired"] = True
                    self._alert(out, s, 0, t, h.ep["zone"], 1)
            elif h.ep:
                out["episodes"].append(dict(tier=0, track=s.id, truth=s.truth, zone=h.ep["zone"],
                                            start=h.ep["start"], end=t))
                h.ep = None
            if h.wrist is None:
                continue

            r = p["matchR"] * scale
            other = s.hands[1 - hi].wrist
            sid = s.id

            def near(lst):
                best, bd = None, r
                for o in lst:
                    c = center(o["box"])
                    d = dist(c, h.wrist)
                    if (d < bd and not (other is not None and dist(c, other) < d)
                            and not any(tid != sid and dist(c, wp) < d for tid, wp in self.frame_wrists)):
                        bd, best = d, o
                return best

            in_shelf = lambda v: any(in_box(v, b) for b in p["shelves"])
            reaching = any(in_box(h.wrist, b, 0.15 * scale) for b in p["shelves"])
            m1 = near(products)
            m2 = near(carried if reaching else [o for o in carried if not in_shelf(center(o["box"]))])
            basket_near = any(dist(center(b["box"]), h.wrist) < p["basketR"] * scale for b in baskets)
            h.h1 = self._update_hold(h.h1, m1, t, h, s, scale, hi, bag, False, basket_near)
            h.h2 = self._update_hold(h.h2, m2, t, h, s, scale, hi, bag, True, basket_near)

            for tier in (1, 2):
                hold = h.h1 if tier == 1 else h.h2
                c = h.c1 if tier == 1 else h.c2
                seen = (m1 if tier == 1 else m2) is not None and hold is not None and hold.lastSeen == t
                if (c is None and fresh and hold is not None and h.zone and hold.frames >= 3
                        and t - hold.start >= p["holdMinS"] - 1e-9 and t - hold.lastSeen <= p["carryGapS"] + 1e-9
                        and not hold.atShelf and dist(hold.pos, h.wrist) <= 1.5 * r):
                    rc = h.recent
                    approach = 0.0
                    if len(rc) >= 2:
                        approach = dist(rc[-1][1], rc[0][1]) / max(1e-3, rc[-1][0] - rc[0][0]) / scale
                    head = 0.0
                    if len(s.head) > 2:
                        mu = 0.0
                        for _, u in s.head:
                            mu += u
                        mu /= len(s.head)
                        acc = 0.0
                        for _, u in s.head:
                            acc += (u - mu) * (u - mu)
                        head = math.sqrt(acc / len(s.head))
                    c = Cand(zone=h.zone, enter=t, holdS=t - hold.start, approach=approach, head=head,
                             hold=hold, basketNear=hold.atBasket, lastWrist=h.wrist)
                if c is not None:
                    if c.leave is None:
                        c.framesInZone += 1
                        c.wconf += h.wconf
                        if seen:
                            c.seenInZone += 1
                        c.lastWrist = h.wrist
                        if not h.zone or t - c.enter > p["maxZoneS"]:
                            c.leave = t
                    if c.leave is not None:
                        c.basketNear = c.basketNear or basket_near or c.hold.atBasket
                        if not seen and fresh:
                            c.unseen += dtF
                        if seen and t > c.leave + 1e-9:
                            c = None
                        elif c.unseen >= p["vanishMinS"] - 1e-9:
                            self._fire(out, s, tier, t, c)
                            if tier == 1:
                                h.h1 = None
                            else:
                                h.h2 = None
                            c = None
                        elif t - c.leave > p["vanishWindowS"]:
                            c = None
                if tier == 1:
                    h.c1 = c
                else:
                    h.c2 = c

    def _zone(self, hi, w, s, bag):
        if bag is not None and in_box(w, bag["box"], 0.4 * max(bag["box"]["w"], bag["box"]["h"])):
            return "bag"
        side = 1 if hi == 0 else -1
        u = (side * (w[0] - s.hip[0])) / s.halfW
        v = (s.hip[1] - w[1]) / s.torso
        if 0.45 <= u <= 1.3 and -0.4 <= v <= 0.25:
            return "pocket"
        if -0.5 <= u < 0.45 and -0.3 <= v <= 0.25:
            return "waist"
        if -1.0 <= u <= 0.3 and 0.3 < v <= 0.95:
            return "chest"
        return None

    def _update_hold(self, hold, m, t, h, s, scale, hi, bag, rich, basket_near):
        if m is not None:
            c = center(m["box"])
            if hold is not None and dist(c, hold.pos) > 0.8 * scale:
                hold = None
            if hold is None:
                near_shelf = any(in_box(h.wrist, b, 0.6 * scale) for b in self.p["shelves"])
                z = self._zone(hi, h.wrist, s, bag)
                hold = Hold(start=t, lastSeen=t, frames=0, pos=c, startWrist=h.wrist, startBox=c,
                            prov="shelf" if near_shelf else ("body" if z else "none"))
            hold.frames += 1
            hold.lastSeen = t
            hold.pos = c
            hold.atBasket = basket_near
            hold.atShelf = any(in_box(h.wrist, b, 0.3 * scale) for b in self.p["shelves"])
            if rich:
                if m["cls"] == "product":
                    hold.prod += m["conf"]
                else:
                    hold.other += m["conf"]
                hold.conf += m["conf"]
                hold.n += 1
                wm = dist(h.wrist, hold.startWrist)
                if wm > 0.6 * scale:
                    hold.motion = min(1.5, dist(c, hold.startBox) / wm)
            return hold
        if hold is not None and t - hold.lastSeen > 1.0 and not (h.c2 if rich else h.c1):
            return None
        return hold

    def _fire(self, out, s, tier, t, c: Cand) -> None:
        leave = c.leave if c.leave is not None else t
        if tier == 1:
            dwell = leave - c.enter
            out["t1"].append(dict(tier=1, t=t, track=s.id, truth=s.truth, zone=c.zone, dwell=dwell,
                                  basketNear=c.basketNear))
            if not c.basketNear and dwell >= self.thr["t1Dwell"] - 1e-9:
                self._alert(out, s, 1, t, c.zone, 1)
            return
        hd = c.hold
        feats = [
            min(8, c.holdS), min(4, leave - c.enter),
            hd.prod / (hd.prod + hd.other) if hd.prod + hd.other > 0 else 0.5,
            1 if hd.prov == "shelf" else 0, 1 if hd.prov == "body" else 0,
            0.5 if hd.motion < 0 else hd.motion,
            c.seenInZone / c.framesInZone if c.framesInZone else 0,
            1 if c.zone == "pocket" else 0, 1 if c.zone == "waist" else 0,
            1 if c.zone == "chest" else 0, 1 if c.zone == "bag" else 0,
            min(8, c.approach), c.wconf / c.framesInZone if c.framesInZone else 0,
            1 if c.basketNear else 0, min(1, c.head), hd.conf / hd.n if hd.n else 0,
        ]
        sc = score(self.model, feats) if self.model else 0
        out["t2"].append(dict(tier=2, t=t, track=s.id, truth=s.truth, zone=c.zone, feats=feats, score=sc))
        if self.model and sc >= self.thr["t2"]:
            self._alert(out, s, 2, t, c.zone, sc)

    def _alert(self, out, s, tier, t, zone, sc) -> None:
        if t - s.lastAlert[tier] < self.p["cooldownS"]:
            return
        s.lastAlert[tier] = t
        out["alerts"].append(dict(tier=tier, t=t, track=s.id, truth=s.truth, zone=zone, score=sc))
