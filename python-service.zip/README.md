# Store-camera theft alerts: RTSP ingest, crash-safe recording, detection engine, till alerts

Working build for an RTSP video pipeline that records reliably, detects concealment from
pose and object detections, and alerts the cashier before the shopper reaches the till.
Every number below was produced by the scripts in this kit on one 2-core Intel Xeon
(2.1 GHz), ffmpeg 6.1.1, MediaMTX v1.15.3.

## Layout

| Path | What it is |
|---|---|
| `ingest/recorder.py` | Supervised ffmpeg recorder: fMP4 flushed per frame, reconnect with backoff, stall watchdog, SQLite segment index, retention, clip export |
| `ingest/reader.py` | Low-latency frame readers (PyAV in-process, ffmpeg pipe) for the detector |
| `detect/engine.py` | Event engine (Python port), identical output to `web/src/core/engine.ts` |
| `detect/run_live.py` | Live loop: substream, YOLOX, RTMPose, tracker, engine, alert, clip |
| `alerts/service.py`, `alerts/cashier.html` | FastAPI alert service, WebSocket push, tablet page with Confirm/Dismiss |
| `bench/` | Synthetic camera with frame-index barcodes, fault-injecting proxy, all benchmarks |
| `web/` | Simulator, TypeScript engine, detection benchmark, the demo site |
| `config/` | Example camera, relay and zone configs; the trained event model |
| `results/` | Raw benchmark output, browser QA, screenshots |

## Run

```bash
pip install -r requirements.txt
scripts/fetch_binaries.sh                       # MediaMTX + YOLOX ONNX (Apache-2.0)
python -m ingest.recorder --config config/cameras.json
uvicorn alerts.service:app --port 8080          # tablet at http://host:8080/cashier
```

Benchmarks:

```bash
python bench/infra_bench.py latency|chaos|gop|capacity
python bench/crash_flush.py
python bench/model_bench.py
python bench/alert_bench.py
cd web && npm ci && npm test && npm run bench    # detection benchmark, ~3 min
node --experimental-strip-types tools/parity.ts && python ../detect/test_parity.py
python tests/test_live_parts.py
```

## Measured

**Detection** (simulated store, 60 held-out camera-hours, 257 concealments; tiers tuned to 85%
on 30 separate hours):

| Engine | Caught | False alerts per camera-hour |
|---|---|---|
| Wrist near a pocket for 1.2 s | 81% | 66.9 |
| Product in hand, then gone at a hiding place | 87% | 4.6 |
| Full engine (provenance, motion, class evidence, learned score) | 87% | 0.28 |

- Full engine at a budget of at most 1 / 0.5 / 0.25 false alerts per camera-hour: 91% / 89% / 86% caught.
- Every caught concealment was flagged before the shopper reached the till or the door; median warning 7 s before the till, 21 s before the door.
- By hiding place: pocket 93/95, chest 45/49, waistband 28/33, own bag 32/49; grabs under half a second 25/31.
- Ablations, Full engine, false alerts per camera-hour:
  - Trained without hard negatives: 0.40 (1.4×).
  - No product-versus-phone evidence: 1.93 (7×).
  - Off-the-shelf detector stand-in: 0.55 (2×), and 84% caught.
  - Eye-level model moved to a ceiling camera: 2.42 (9×).
  - Retrained for the ceiling: 0.38, but 71% caught.
  - Twice / four times as many shoppers in view: 0.60 / 1.27, with 83% / 79% caught. Crowding is the main open risk; own-bag concealments suffer most.
- Weekly retraining on cashier taps (5% wrong), starting from staged footage only: 0.40 → 0.25 false alerts per camera-hour in two weeks, catch rate held at 87%.
- Python engine equals the TypeScript engine on 21,600 replayed frames: 55 alerts, 3,019 episodes, 0 mismatches, largest score difference 1e-17. Python cost 0.05 ms per frame.

**Streaming and recording** (loopback, synthetic camera stamping its frame number into every frame):

- Camera to decoded frame, 15 fps, 2 s keyframes:
  - ffmpeg defaults: 271 ms.
  - nobuffer, low_delay and no probing: 137 ms.
  - PyAV in-process: 71 ms.
  - The MediaMTX relay hop adds under 1 ms.
- Recorder killed with SIGKILL, worst of five:
  - plain MP4: 9.0 s lost (everything);
  - fMP4 without flushing: 3.9 s;
  - MPEG-TS: 2.8 s;
  - fMP4 per-frame fragments with `flush_packets`: 0.2 s;
  - MPEG-TS with flush: 0.13 s.
- Fault injection, seconds lost beyond the fault:

| Fault | This recorder (fMP4, flushed) | MediaMTX recorder | Plain MP4 |
|---|---|---|---|
| Camera reboot, 6 s | 2.1 | 4.2 | 2.1 |
| Network freeze, 8 s | 0 lost | 0 lost | 0 lost |
| Connection reset | 2.1 | 6.2 | 2.1 |
| Recorder killed | 2.3 | 2.9 | 10.0 (the whole open segment) |

- Gap after a reconnect is about one keyframe interval: 1.1 s, 2.1 s and 4.1 s for 1, 2 and 4 s keyframes.
- A 15 s alert clip is cut from the recording in 74 ms without re-encoding, covering the whole window.
- Copy-recording 8 cameras costs 2.5% of one core.
- Decoding H.264 on one core: 11.6 cameras at 1080p, 65 at 360p (15 fps).
- YOLOX-Nano at 416 px takes 13 ms on one core; YOLOX-S at 640 px takes 109 ms on two.
- Alert service: 1,800 of 1,800 deliveries to 3 WebSocket tablets; median 2.3 ms, 95th percentile 2.9 ms.

**Tests**:
- TypeScript: 12 of 12 (vitest).
- Python: 7 of 7.
- Browser QA of the site: see `results/qa.json`.

## Not measured

- Accuracy on real store footage. Shoppers, the pose model and the object detector are simulated, so every detection number above describes the logic, not a trained model on your cameras.
- The "off-the-shelf" and "fine-tuned" detectors are stand-in confusion rates, not trained models.
- Real cameras, hardware encoders and a real network: latency was measured on loopback.
- GPU or accelerator throughput: CPU only here.
- RTMPose in `detect/run_live.py`: written to the published SimCC decoding, but never run here, because the weights come from OpenMMLab, which this environment could not reach.
- `docker-compose.yml`: never run here, because there was no Docker daemon.

## Licences

- MediaMTX: MIT.
- YOLOX: Apache-2.0.
- MMPose / RTMPose: Apache-2.0.
- Ultralytics YOLO: AGPL-3.0, with a paid Enterprise licence for closed commercial use.
