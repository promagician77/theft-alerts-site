"""Cashier alert service.

POST /events      the detector reports a suspected concealment; pushed at once to every
                  cashier tablet over WebSocket
POST /events/{id}/clip   attach the evidence clip once it is cut (a second or so later)
POST /feedback    cashier taps Confirm or Dismiss; stored as a training label
GET  /cashier     the tablet page
GET  /alerts      recent alerts with labels (for review and retraining)
WS   /ws          tablet connection

Run: uvicorn alerts.service:app --host 0.0.0.0 --port 8080
"""
from __future__ import annotations

import asyncio
import json
import sqlite3
import time
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel

DB = Path(__file__).with_name("alerts.db")
CLIPS = Path(__file__).with_name("clips")
CLIPS.mkdir(exist_ok=True)

app = FastAPI(title="Theft alerts")
db = sqlite3.connect(DB, check_same_thread=False)
db.execute("CREATE TABLE IF NOT EXISTS alerts (id INTEGER PRIMARY KEY, camera TEXT, t_event REAL, t_sent REAL,"
           " track INT, zone TEXT, score REAL, clip TEXT, label TEXT, t_label REAL, features TEXT)")
db.commit()
clients: set[WebSocket] = set()
lock = asyncio.Lock()


class Event(BaseModel):
    camera: str
    t_event: float
    track: int
    zone: str
    score: float
    features: list[float] = []
    t_sent: float | None = None


class Clip(BaseModel):
    url: str


class Feedback(BaseModel):
    alert_id: int
    label: str   # "confirm" | "dismiss"


async def broadcast(msg: dict) -> None:
    data = json.dumps(msg)
    dead = []
    for ws in list(clients):
        try:
            await ws.send_text(data)
        except Exception:
            dead.append(ws)
    for ws in dead:
        clients.discard(ws)


@app.post("/events")
async def events(e: Event):
    t_sent = e.t_sent or time.time()
    async with lock:
        cur = db.execute("INSERT INTO alerts (camera, t_event, t_sent, track, zone, score, features) VALUES (?,?,?,?,?,?,?)",
                         (e.camera, e.t_event, t_sent, e.track, e.zone, e.score, json.dumps(e.features)))
        db.commit()
        aid = cur.lastrowid
    await broadcast({"type": "alert", "id": aid, "camera": e.camera, "zone": e.zone, "score": round(e.score, 3),
                     "t_event": e.t_event, "t_sent": t_sent})
    return {"id": aid}


@app.post("/events/{aid}/clip")
async def clip(aid: int, c: Clip):
    db.execute("UPDATE alerts SET clip=? WHERE id=?", (c.url, aid))
    db.commit()
    await broadcast({"type": "clip", "id": aid, "url": c.url})
    return {"ok": True}


@app.post("/feedback")
async def feedback(f: Feedback):
    if f.label not in ("confirm", "dismiss"):
        return {"ok": False}
    db.execute("UPDATE alerts SET label=?, t_label=? WHERE id=?", (f.label, time.time(), f.alert_id))
    db.commit()
    await broadcast({"type": "label", "id": f.alert_id, "label": f.label})
    return {"ok": True}


@app.get("/alerts")
async def alerts(limit: int = 100):
    rows = db.execute("SELECT id, camera, t_event, zone, score, clip, label FROM alerts ORDER BY id DESC LIMIT ?",
                      (limit,)).fetchall()
    return [dict(zip(("id", "camera", "t_event", "zone", "score", "clip", "label"), r)) for r in rows]


@app.get("/clips/{name}")
async def clips(name: str):
    p = (CLIPS / name).resolve()
    if p.parent != CLIPS.resolve() or not p.exists():
        return HTMLResponse("not found", status_code=404)
    return FileResponse(p, media_type="video/mp4")


@app.websocket("/ws")
async def ws(sock: WebSocket):
    await sock.accept()
    clients.add(sock)
    try:
        while True:
            await sock.receive_text()   # keepalive pings from the tablet
    except WebSocketDisconnect:
        clients.discard(sock)


@app.get("/cashier")
async def cashier():
    return HTMLResponse(Path(__file__).with_name("cashier.html").read_text())
