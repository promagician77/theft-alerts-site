#!/usr/bin/env python3
"""Streaming and recording benchmarks. Every number on the site comes from here.

  latency   glass-to-decoded latency for six reader settings (frame-index barcodes)
  chaos     camera reboot, network stall, connection reset and two recorder crashes
            against four recorder designs; counts every lost frame
  capacity  decode cost per resolution, copy-recording cost for 8 cameras
  all       run the three in sequence

Everything runs on loopback on this machine: numbers include encode, RTSP, relay and
decode, but not a real camera's encoder or a real LAN.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ingest import barcode  # noqa: E402
from ingest.reader import FfmpegReader, PyAVReader  # noqa: E402
from ingest.recorder import CameraConfig, CameraRecorder, SegmentIndex, export_clip  # noqa: E402

MTX = str(ROOT / "bin" / "mediamtx")
RESULTS = ROOT / "results"
FPS = 15.0
W, H = 960, 540
CX, CY, CW, CH = barcode.CROP


# ---------------------------------------------------------------- helpers
def mtx_config(path: Path, port: int, rtp: int, paths: dict) -> Path:
    lines = [
        "logLevel: warn", "rtspTransports: [udp, tcp]",
        f"rtspAddress: :{port}", f"rtpAddress: :{rtp}", f"rtcpAddress: :{rtp + 1}",
        f"multicastRTPPort: {rtp + 2}", f"multicastRTCPPort: {rtp + 3}",
        "rtmp: no", "hls: no", "webrtc: no", "srt: no", "api: no", "metrics: no",
        "playback: no", "pprof: no", "paths:",
    ]
    for name, opts in paths.items():
        lines.append(f"  {name}:")
        for k, v in opts.items():
            lines.append(f"    {k}: {v}")
    path.write_text("\n".join(lines) + "\n")
    return path


def spawn(cmd: list[str], log: Path | None = None) -> subprocess.Popen:
    out = open(log, "ab") if log else subprocess.DEVNULL
    return subprocess.Popen(cmd, stdout=out, stderr=out, stdin=subprocess.DEVNULL,
                            start_new_session=True)


def kill(p: subprocess.Popen | None, sig: int = signal.SIGKILL) -> None:
    if p and p.poll() is None:
        try:
            os.killpg(p.pid, sig)
        except ProcessLookupError:
            pass
        try:
            p.wait(timeout=8)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGKILL)
            p.wait()


def camera(url: str, t0: float, log: Path, gop: float = 2.0) -> subprocess.Popen:
    return spawn([sys.executable, str(ROOT / "bench" / "camera_sim.py"), "--url", url,
                  "--fps", str(FPS), "--size", f"{W}x{H}", "--gop", str(gop),
                  "--t0", str(t0), "--log", str(log)])


def read_cam_log(log: Path) -> dict[int, float]:
    m: dict[int, float] = {}
    for line in log.read_text().splitlines():
        k, t = line.split(",")
        m[int(k)] = float(t)
    return m


def wait_for(cond, timeout: float, step: float = 0.1) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(step)
    return False


def pct(a, q):
    return float(np.percentile(np.asarray(a), q)) if len(a) else None


def decode_indices(path: str) -> tuple[list[int], bool]:
    """All frame indices in a recorded file, and whether ffmpeg opened it at all."""
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", path, "-map", "0:v",
           "-vf", f"crop={CW}:{CH}:{CX}:{CY}", "-pix_fmt", "gray", "-f", "rawvideo",
           "-fps_mode", "passthrough", "pipe:1"]
    r = subprocess.run(cmd, capture_output=True)
    n = CW * CH
    data = r.stdout
    idx = []
    for i in range(len(data) // n):
        k = barcode.read_crop(np.frombuffer(data[i * n:(i + 1) * n], np.uint8).reshape(CH, CW))
        if k is not None:
            idx.append(k)
    opened = not (b"moov atom not found" in r.stderr or b"Invalid data found" in r.stderr) or bool(idx)
    return idx, opened


def save(section: str, data: dict) -> None:
    RESULTS.mkdir(exist_ok=True)
    f = RESULTS / "infra.json"
    allr = json.loads(f.read_text()) if f.exists() else {}
    allr[section] = data
    allr["machine"] = {"cpu": cpu_name(), "cores": os.cpu_count(),
                       "ffmpeg": subprocess.run(["ffmpeg", "-version"], capture_output=True,
                                                text=True).stdout.split("\n")[0],
                       "mediamtx": subprocess.run([MTX, "--version"], capture_output=True,
                                                  text=True).stdout.strip()}
    f.write_text(json.dumps(allr, indent=1))


def cpu_name() -> str:
    for line in Path("/proc/cpuinfo").read_text().splitlines():
        if line.startswith("model name"):
            return line.split(":", 1)[1].strip()
    return "unknown"


# ---------------------------------------------------------------- latency
def latency(seconds: float = 30.0) -> dict:
    work = Path(tempfile.mkdtemp(prefix="lat_"))
    cam_cfg = mtx_config(work / "cam.yml", 8554, 8000, {"cam1": {"source": "publisher"}})
    relay_cfg = mtx_config(work / "relay.yml", 9554, 9000, {"cam1": {
        "source": "rtsp://127.0.0.1:8554/cam1", "rtspTransport": "tcp", "sourceOnDemand": "no"}})
    cam_srv = spawn([MTX, str(cam_cfg)], work / "cam_srv.log")
    time.sleep(0.5)
    t0 = time.time()
    cam_log = work / "cam.log"
    cam = camera("rtsp://127.0.0.1:8554/cam1", t0, cam_log)
    wait_for(lambda: cam_log.exists() and cam_log.stat().st_size > 2000, 15)
    relay = spawn([MTX, str(relay_cfg)], work / "relay.log")
    time.sleep(3)

    direct, relay_url = "rtsp://127.0.0.1:8554/cam1", "rtsp://127.0.0.1:9554/cam1"
    crop = f"crop={CW}:{CH}:{CX}:{CY}"
    configs = [
        ("direct_default", "ffmpeg defaults, camera direct",
         lambda: FfmpegReader(direct, CW, CH, low_latency=False, vf=crop)),
        ("direct_lowlat", "nobuffer + low_delay + no probing",
         lambda: FfmpegReader(direct, CW, CH, low_latency=True, single_thread=False, vf=crop)),
        ("direct_lowlat_1t", "+ single-thread decode",
         lambda: FfmpegReader(direct, CW, CH, low_latency=True, single_thread=True, vf=crop)),
        ("relay_lowlat_1t", "same, through the MediaMTX relay",
         lambda: FfmpegReader(relay_url, CW, CH, low_latency=True, vf=crop)),
        ("relay_pyav", "PyAV in-process, through the relay",
         lambda: PyAVReader(relay_url, crop=(CX, CY, CW, CH))),
        ("relay_udp", "RTP over UDP, through the relay",
         lambda: FfmpegReader(relay_url, CW, CH, transport="udp", vf=crop)),
    ]
    out = {"seconds_per_config": seconds, "fps": FPS, "gop_s": 2.0, "resolution": f"{W}x{H}",
           "configs": []}
    for key, label, make in configs:
        samples: list[tuple[int, float]] = []
        launched = time.time()
        rdr = make()
        stop = threading.Event()

        def consume():
            try:
                for t, img in rdr.frames():
                    k = barcode.read_crop(img)
                    if k is not None:
                        samples.append((k, t))
                    if stop.is_set():
                        break
            except Exception:
                pass

        th = threading.Thread(target=consume, daemon=True)
        th.start()
        time.sleep(seconds)
        stop.set()
        th.join(timeout=3)
        rdr.close()
        th.join(timeout=3)
        cam_map = read_cam_log(cam_log)
        first = samples[0][1] - launched if samples else None
        warm = [s for s in samples if s[1] - launched > 3.0]
        lat = [(t - cam_map[k]) * 1000 for k, t in warm if k in cam_map]
        expected = int((warm[-1][1] - warm[0][1]) * FPS) + 1 if len(warm) > 1 else 0
        out["configs"].append({
            "key": key, "label": label, "frames": len(lat),
            "p50_ms": pct(lat, 50), "p95_ms": pct(lat, 95), "p99_ms": pct(lat, 99),
            "max_ms": max(lat) if lat else None, "join_s": first,
            "delivered_pct": 100.0 * len(warm) / expected if expected else None,
        })
        print(key, {k: (round(v, 1) if isinstance(v, float) else v)
                    for k, v in out["configs"][-1].items() if k != "label"}, flush=True)
        time.sleep(1)
    kill(cam)
    kill(relay)
    kill(cam_srv)
    shutil.rmtree(work, ignore_errors=True)
    save("latency", out)
    return out


# ---------------------------------------------------------------- chaos
FAULTS = [  # (t from start, kind, duration)
    (30.0, "camera_reboot", 6.0),
    (70.0, "network_stall", 8.0),
    (110.0, "connection_reset", 0.0),
    (140.0, "recorder_crash", 0.0),
    (163.0, "recorder_crash", 0.0),
]
RUN_S = 195.0
VARIANTS = [  # name, label
    ("ff_fmp4", "ffmpeg segments, fragmented MP4 (1 s fragments)"),
    ("ff_ts", "ffmpeg segments, MPEG-TS"),
    ("ff_mp4", "ffmpeg segments, plain MP4"),
    ("mtx_fmp4", "MediaMTX relay recording, fMP4 (1 s parts)"),
]


def chaos(gop: float = 2.0, segment_s: int = 10, faults=FAULTS, run_s: float = RUN_S,
          tag: str = "chaos") -> dict:
    work = Path(tempfile.mkdtemp(prefix="chaos_"))
    rec = work / "rec"
    cam_cfg = mtx_config(work / "cam.yml", 8554, 8000, {"cam1": {"source": "publisher"}})
    relay_cfg = mtx_config(work / "relay.yml", 9554, 9000, {"cam1": {
        "source": "rtsp://127.0.0.1:7554/cam1", "rtspTransport": "tcp", "sourceOnDemand": "no",
        "record": "yes", "recordPath": str(rec / "mtx_fmp4" / "%path" / "%Y-%m-%d_%H-%M-%S-%f"),
        "recordFormat": "fmp4", "recordPartDuration": "1s",
        "recordSegmentDuration": f"{segment_s}s", "recordDeleteAfter": "0s"}})
    cam_srv = spawn([MTX, str(cam_cfg)], work / "cam_srv.log")
    proxy = spawn([sys.executable, str(ROOT / "bench" / "tcpproxy.py"),
                   "--listen", "7554", "--target", "8554"])
    time.sleep(0.6)
    t0 = time.time()
    cam_log = work / "cam.log"
    cam = camera("rtsp://127.0.0.1:8554/cam1", t0, cam_log, gop)
    wait_for(lambda: cam_log.exists() and cam_log.stat().st_size > 1000, 15)
    index = SegmentIndex(str(work / "segments.db"))
    events: list = []
    url = "rtsp://127.0.0.1:7554/cam1"
    recs = {}
    for name, fmt in (("ff_fmp4", "fmp4"), ("ff_ts", "ts"), ("ff_mp4", "mp4")):
        recs[name] = CameraRecorder(CameraConfig(name=name, url=url, out_dir=str(rec), fmt=fmt,
                                                 segment_s=segment_s), index, events)
    relay = spawn([MTX, str(relay_cfg)], work / "relay.log")
    t_start = time.time()
    for r in recs.values():
        r.start()

    fault_log = []
    for at, kind, dur in faults:
        while time.time() < t_start + at:
            time.sleep(0.02)
        t_f = time.time()
        if kind == "camera_reboot":
            kill(cam)
            time.sleep(dur)
            cam = camera("rtsp://127.0.0.1:8554/cam1", t0, cam_log, gop)
        elif kind == "network_stall":
            os.kill(proxy.pid, signal.SIGUSR1)
            time.sleep(dur)
            os.kill(proxy.pid, signal.SIGUSR2)
        elif kind == "connection_reset":
            os.kill(proxy.pid, signal.SIGHUP)
        elif kind == "recorder_crash":
            for r in recs.values():
                if r.proc and r.proc.poll() is None:
                    r.proc.kill()            # supervisor restarts it
            kill(relay)                      # container-style restart after 0.5 s
            time.sleep(0.5)
            relay = spawn([MTX, str(relay_cfg)], work / "relay.log")
        fault_log.append({"kind": kind, "t": t_f, "dur": dur, "k": int((t_f - t0) * FPS)})
        print(f"fault {kind} at {t_f - t_start:.1f}s", flush=True)
    while time.time() < t_start + run_s:
        time.sleep(0.1)
    t_end = time.time()
    for r in recs.values():
        r.stop()
    for r in recs.values():
        r.join(timeout=15)
    kill(relay, signal.SIGINT)
    kill(cam)
    kill(proxy)
    kill(cam_srv)

    raw = {"t0": t0, "t_start": t_start, "t_end": t_end, "faults": fault_log, "events": events}
    (RESULTS / f"{tag}_raw.json").write_text(json.dumps(raw))

    # -------- analysis
    k_lo = int((t_start + 6 - t0) * FPS)
    k_hi = int((t_end - 10 - t0) * FPS)
    sent = read_cam_log(cam_log)
    result = {"gop_s": gop, "segment_s": segment_s, "fps": FPS, "run_s": run_s,
              "window_frames": k_hi - k_lo, "faults": [], "variants": []}
    for f in fault_log:
        result["faults"].append({"kind": f["kind"], "at_s": round(f["t"] - t_start, 2),
                                 "dur_s": f["dur"]})
    for name, label in VARIANTS:
        files = sorted(str(p) for p in (rec / name).rglob("*") if p.is_file()
                       and p.suffix in (".mp4", ".ts"))
        got: set[int] = set()
        empty_files: list[int] = []
        unplayable, dupes = 0, 0
        for fp in files:
            idx, opened = decode_indices(fp)
            if not idx:
                unplayable += 1
                empty_files.append(Path(fp).stat().st_size)
            dupes += len(idx) - len(set(idx))
            got.update(idx)
        missing = [k for k in range(k_lo, k_hi) if k not in got]
        runs = []
        for k in missing:
            if runs and k == runs[-1][1] + 1:
                runs[-1][1] = k
            else:
                runs.append([k, k])
        to_s = lambda k: round(t0 + k / FPS - t_start, 2)
        gaps = [{"from_s": to_s(a), "to_s": to_s(b + 1), "dur_s": round((b - a + 1) / FPS, 2)} for a, b in runs]
        fl = [{"kind": f["kind"], "at_s": f["t"] - t_start, "dur": f["dur"]} for f in fault_log]
        per = [0.0] * len(fl)
        unexplained = 0.0
        for g in gaps:   # a gap belongs to the fault inside it, else the latest fault before it
            inside = [i for i, f in enumerate(fl) if g["from_s"] - 0.5 <= f["at_s"] <= g["to_s"] + 1.0]
            before = [i for i, f in enumerate(fl) if f["at_s"] <= g["from_s"]]
            if inside:
                per[inside[0]] += g["dur_s"]
            elif before and g["from_s"] - fl[before[-1]]["at_s"] - fl[before[-1]]["dur"] < 15:
                per[before[-1]] += g["dur_s"]
            else:
                unexplained += g["dur_s"]
        per_fault = [{"kind": f["kind"], "lost_s": round(per[i], 2), "extra_s": round(per[i] - f["dur"], 2)}
                     for i, f in enumerate(fl)]
        result["variants"].append({
            "name": name, "label": label, "files": len(files), "unplayable_files": unplayable,
            "duplicates": dupes, "recorded_pct": round(100 * (1 - len(missing) / (k_hi - k_lo)), 2),
            "faults": per_fault,
            "unexplained_lost_s": round(unexplained, 2),
            "bytes": sum(Path(fp).stat().st_size for fp in files),
            "gaps": gaps, "empty_file_bytes": empty_files,
            "events": [{"t_s": round(e["t"] - t_start, 2), "kind": e["kind"], "reason": e.get("reason", "")}
                       for e in events if e["cam"] == name],
        })
        print(name, json.dumps(result["variants"][-1]["faults"]), "unexplained",
              result["variants"][-1]["unexplained_lost_s"], "unplayable", unplayable, flush=True)

    # -------- clip export check (fMP4 recorder, an "alert" 95 s in)
    t_evt = t_start + 95.0
    clip = export_clip(index, "ff_fmp4", t_evt - 10, t_evt + 5, str(work / "clip.mp4"))
    if clip["ok"]:
        idx, _ = decode_indices(clip["path"])
        want_lo, want_hi = int((t_evt - 10 - t0) * FPS), int((t_evt + 5 - t0) * FPS)
        inside = [k for k in range(want_lo, want_hi) if k not in set(idx)]
        clip.update({"requested_s": 15, "covered": not inside, "missing_in_window": len(inside),
                     "starts_early_s": round((want_lo - min(idx)) / FPS, 2) if idx else None,
                     "ends_late_s": round((max(idx) - want_hi) / FPS, 2) if idx else None,
                     "clip_frames": len(idx)})
    clip.pop("path", None)
    clip.pop("err", None)
    result["clip_export"] = clip
    result["restarts"] = {n: sum(1 for e in events if e["cam"] == n and e["kind"] == "restart")
                          for n in recs}
    result["sent_frames"] = len(sent)
    save(tag, result)
    shutil.rmtree(work, ignore_errors=True)
    return result


# ---------------------------------------------------------------- capacity
def proc_cpu(pid: int) -> float:
    f = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
    return (int(f[11]) + int(f[12])) / os.sysconf("SC_CLK_TCK")


def tree_cpu(pid: int) -> float:
    total = 0.0
    try:
        total += proc_cpu(pid)
        for ch in Path(f"/proc/{pid}/task/{pid}/children").read_text().split():
            total += tree_cpu(int(ch))
    except (FileNotFoundError, ProcessLookupError):
        pass
    return total


def make_clip(path: Path, w: int, h: int, seconds: int = 20, fps: float = 15.0,
              bitrate: str = "1500k") -> None:
    if path.exists():
        return
    bg = np.random.default_rng(1).integers(40, 120, (h, w), dtype=np.uint8)
    p = subprocess.Popen(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "rawvideo",
                          "-pix_fmt", "gray", "-s", f"{w}x{h}", "-framerate", str(fps), "-i", "-",
                          "-c:v", "libx264", "-preset", "veryfast", "-g", str(int(2 * fps)),
                          "-bf", "0", "-b:v", bitrate, "-pix_fmt", "yuv420p", str(path)],
                         stdin=subprocess.PIPE)
    for k in range(int(seconds * fps)):
        y = np.roll(bg, k * 3, axis=1)
        y[h // 3:h // 3 + h // 6, (k * 7) % (w - 60):(k * 7) % (w - 60) + 60] = 220
        if w >= 600:
            barcode.stamp(y, k)
        p.stdin.write(y.tobytes())
    p.stdin.close()
    p.wait()


def capacity() -> dict:
    work = ROOT / "results" / "clips"
    work.mkdir(parents=True, exist_ok=True)
    out: dict = {"decode": [], "recording": {}}
    for w, h, br in ((1920, 1080, "4000k"), (960, 540, "1500k"), (640, 360, "700k")):
        f = work / f"loop_{h}p.mp4"
        make_clip(f, w, h, bitrate=br)
        best = None
        for _ in range(2):
            t = time.time()
            r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-threads", "1",
                                "-i", str(f), "-f", "null", "-"], capture_output=True)
            dt = time.time() - t
            best = dt if best is None else min(best, dt)
        frames = 20 * 15
        fps1 = frames / best
        out["decode"].append({"resolution": f"{w}x{h}", "decode_fps_one_core": round(fps1, 1),
                              "cameras_per_core_at_15fps": round(fps1 / 15, 1)})
        print("decode", out["decode"][-1], flush=True)

    # 8 cameras: copy-recording cost, MediaMTX relay vs ffmpeg segmenters
    n = 8
    tmp = Path(tempfile.mkdtemp(prefix="cap_"))
    paths = {f"cam{i}": {"source": "publisher"} for i in range(n)}
    cam_srv = spawn([MTX, str(mtx_config(tmp / "cam.yml", 8554, 8000, paths))])
    time.sleep(0.5)
    pubs = [spawn(["ffmpeg", "-hide_banner", "-loglevel", "error", "-re", "-stream_loop", "-1",
                   "-i", str(work / "loop_540p.mp4"), "-c", "copy", "-f", "rtsp",
                   "-rtsp_transport", "tcp", f"rtsp://127.0.0.1:8554/cam{i}"]) for i in range(n)]
    time.sleep(3)
    rpaths = {f"cam{i}": {"source": f"rtsp://127.0.0.1:8554/cam{i}", "rtspTransport": "tcp",
                          "sourceOnDemand": "no", "record": "yes",
                          "recordPath": str(tmp / "rec" / "%path" / "%Y-%m-%d_%H-%M-%S-%f"),
                          "recordFormat": "fmp4", "recordPartDuration": "1s",
                          "recordSegmentDuration": "10s", "recordDeleteAfter": "0s"}
              for i in range(n)}
    relay = spawn([MTX, str(mtx_config(tmp / "relay.yml", 9554, 9000, rpaths))])
    time.sleep(4)
    win = 30.0
    c0, t = proc_cpu(relay.pid), time.time()
    time.sleep(win)
    relay_core = (proc_cpu(relay.pid) - c0) / (time.time() - t)
    kill(relay)
    idx = SegmentIndex(str(tmp / "seg.db"))
    recs = [CameraRecorder(CameraConfig(name=f"cam{i}", url=f"rtsp://127.0.0.1:8554/cam{i}",
                                        out_dir=str(tmp / "ff")), idx) for i in range(n)]
    for r in recs:
        r.start()
    time.sleep(4)
    pids = [r.proc.pid for r in recs if r.proc]
    c0, t = sum(proc_cpu(p) for p in pids), time.time()
    time.sleep(win)
    ff_core = (sum(proc_cpu(p) for p in pids) - c0) / (time.time() - t)
    for r in recs:
        r.stop()
    for r in recs:
        r.join(timeout=10)
    for p in pubs:
        kill(p)
    kill(cam_srv)
    out["recording"] = {
        "cameras": n, "stream": "960x540 H.264 15 fps 1.5 Mbit/s",
        "mediamtx_relay_record_core_pct_total": round(100 * relay_core, 2),
        "ffmpeg_segmenters_core_pct_total": round(100 * ff_core, 2),
        "mediamtx_per_camera_core_pct": round(100 * relay_core / n, 2),
        "ffmpeg_per_camera_core_pct": round(100 * ff_core / n, 2),
    }
    print("recording", out["recording"], flush=True)
    shutil.rmtree(tmp, ignore_errors=True)
    save("capacity", out)
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("what", choices=["latency", "chaos", "gop", "capacity", "all"])
    a = ap.parse_args()
    if a.what in ("latency", "all"):
        latency()
    if a.what in ("chaos", "all"):
        chaos()
    if a.what in ("gop", "all"):
        res = {}
        for g in (1.0, 4.0):
            r = chaos(gop=g, faults=[(20.0, "camera_reboot", 6.0), (50.0, "connection_reset", 0.0),
                                     (80.0, "recorder_crash", 0.0)], run_s=110.0, tag=f"gop_{g:g}")
            res[f"{g:g}"] = r
    if a.what in ("capacity", "all"):
        capacity()
