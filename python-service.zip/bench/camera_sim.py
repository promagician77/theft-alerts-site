#!/usr/bin/env python3
"""Synthetic RTSP camera for benchmarks.

Renders a moving top-down store scene, stamps each frame's index into the pixels,
encodes H.264 with x264 (zerolatency) and publishes over RTSP. The frame index is a
clock: frame k belongs to time t0 + k / fps, so gaps in recordings convert directly
to seconds. Every frame actually handed to the encoder is logged as "k,t_write".

Killing this process is how the benchmark simulates a camera reboot; restarting it
with the same --t0 keeps the index-to-time mapping.
"""
from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from ingest import barcode  # noqa: E402


def build_background(w: int, h: int) -> np.ndarray:
    yy, xx = np.mgrid[0:h, 0:w]
    floor = (70 + 25 * np.sin(xx / 37.0) * np.cos(yy / 53.0)).astype(np.uint8)
    # shelves: darker bands
    for x in range(80, w - 80, 170):
        floor[60:h - 120, x:x + 46] = 40
    floor[h - 90:h - 40, w - 300:w - 40] = 110   # checkout counter
    return floor


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--fps", type=float, default=15.0)
    ap.add_argument("--size", default="960x540")
    ap.add_argument("--gop", type=float, default=2.0, help="keyframe interval in seconds")
    ap.add_argument("--bitrate", default="1500k")
    ap.add_argument("--t0", type=float, required=True, help="shared epoch for the frame clock")
    ap.add_argument("--log", required=True)
    ap.add_argument("--duration", type=float, default=1e9)
    a = ap.parse_args()

    w, h = map(int, a.size.split("x"))
    g = max(1, int(round(a.gop * a.fps)))
    bg = build_background(w, h)
    uv = np.full((h // 2) * (w // 2) * 2, 128, np.uint8).tobytes()
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
        "-f", "rawvideo", "-pix_fmt", "yuv420p", "-s", f"{w}x{h}", "-framerate", str(a.fps),
        "-use_wallclock_as_timestamps", "1", "-i", "-",
        "-c:v", "libx264", "-preset", "ultrafast", "-tune", "zerolatency",
        "-g", str(g), "-keyint_min", str(g), "-sc_threshold", "0", "-bf", "0",
        "-b:v", a.bitrate, "-maxrate", a.bitrate, "-bufsize", a.bitrate,
        "-fps_mode", "passthrough", "-f", "rtsp", "-rtsp_transport", "tcp", a.url,
    ]
    proc: subprocess.Popen | None = None
    last_try = 0.0
    log = open(a.log, "a", buffering=1)

    def stop(*_):
        if proc and proc.poll() is None:
            proc.kill()
        sys.exit(0)

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)

    k = int(np.floor((time.time() - a.t0) * a.fps)) + 1
    t_end = time.time() + a.duration
    blobs = np.random.default_rng(7).uniform(0, 1, (6, 4))
    while time.time() < t_end:
        target = a.t0 + k / a.fps
        now = time.time()
        if now < target:
            time.sleep(target - now)
        elif now - target > 1.0 / a.fps:
            k = int(np.floor((now - a.t0) * a.fps)) + 1  # fell behind: skip, keep the clock
            continue
        if proc is None or proc.poll() is not None:
            if time.time() - last_try < 0.2:
                k += 1
                continue
            last_try = time.time()
            proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)
        y = np.roll(bg, (k * 2) % w, axis=1)
        t = k / a.fps
        for bx, by, sx, sy in blobs:   # moving "shoppers"
            cx = int((bx * w + 40 * t * (sx - 0.5)) % (w - 40))
            cy = int(80 + (by * (h - 200) + 25 * t * (sy - 0.5)) % (h - 200))
            y[cy:cy + 34, cx:cx + 22] = 200
        barcode.stamp(y, k)
        try:
            t_write = time.time()
            proc.stdin.write(y.tobytes())
            proc.stdin.write(uv)
            proc.stdin.flush()
            log.write(f"{k},{t_write:.6f}\n")
        except (BrokenPipeError, OSError, ValueError):
            try:
                proc.kill()
            except Exception:
                pass
            proc = None
        k += 1
    stop()


if __name__ == "__main__":
    main()
