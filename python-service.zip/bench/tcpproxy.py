#!/usr/bin/env python3
"""Fault-injecting TCP proxy that sits between recorders and the camera.

Signals:
  SIGUSR1  stall: stop forwarding in both directions (sockets stay open), the way
           a frozen switch or saturated uplink looks to a recorder
  SIGUSR2  resume forwarding
  SIGHUP   reset: abort every open connection at once
"""
from __future__ import annotations

import argparse
import asyncio
import signal


async def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--listen", type=int, required=True)
    ap.add_argument("--target", type=int, required=True)
    a = ap.parse_args()

    flowing = asyncio.Event()
    flowing.set()
    conns: set[asyncio.StreamWriter] = set()

    async def pump(r: asyncio.StreamReader, w: asyncio.StreamWriter) -> None:
        try:
            while True:
                await flowing.wait()
                data = await r.read(65536)
                if not data:
                    break
                await flowing.wait()
                w.write(data)
                await w.drain()
        except Exception:
            pass
        finally:
            try:
                w.close()
            except Exception:
                pass

    async def handle(cr: asyncio.StreamReader, cw: asyncio.StreamWriter) -> None:
        try:
            ur, uw = await asyncio.open_connection("127.0.0.1", a.target)
        except Exception:
            cw.close()
            return
        conns.update({cw, uw})
        await asyncio.gather(pump(cr, uw), pump(ur, cw))
        conns.discard(cw)
        conns.discard(uw)

    def reset() -> None:
        for w in list(conns):
            try:
                w.transport.abort()
            except Exception:
                pass
        conns.clear()

    loop = asyncio.get_running_loop()
    loop.add_signal_handler(signal.SIGUSR1, flowing.clear)
    loop.add_signal_handler(signal.SIGUSR2, flowing.set)
    loop.add_signal_handler(signal.SIGHUP, reset)
    server = await asyncio.start_server(handle, "127.0.0.1", a.listen)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
