#!/usr/bin/env bash
# MediaMTX (MIT) and the Apache-2.0 YOLOX models used by the benchmarks.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p bin models
curl -sSL https://github.com/bluenviron/mediamtx/releases/download/v1.15.3/mediamtx_v1.15.3_linux_amd64.tar.gz | tar -xz -C bin mediamtx
curl -sSL -o models/yolox_nano.onnx https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_nano.onnx
curl -sSL -o models/yolox_s.onnx https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_s.onnx
echo "ok: bin/mediamtx, models/yolox_nano.onnx, models/yolox_s.onnx"
