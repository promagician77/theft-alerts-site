"""Tests for the parts of the live loop that can run without pose weights."""
from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from detect.run_live import IouTracker, Yolox, letterbox, nms, yolox_postprocess  # noqa: E402
from ingest import barcode  # noqa: E402
from ingest.recorder import SegmentIndex, enforce_retention  # noqa: E402


def test_letterbox_keeps_aspect():
    img = np.zeros((540, 960, 3), np.uint8)
    out, r = letterbox(img, 416)
    assert out.shape == (416, 416, 3) and abs(r - 416 / 960) < 1e-9
    assert out[-1, -1, 0] == 114   # padding


def test_nms_drops_overlaps():
    b = np.array([[0, 0, 10, 10], [1, 1, 11, 11], [50, 50, 60, 60]], float)
    keep = nms(b, np.array([0.9, 0.8, 0.7]))
    assert keep == [0, 2]


def test_yolox_postprocess_synthetic_peak():
    size = 416
    n = sum((size // s) ** 2 for s in (8, 16, 32))
    raw = np.full((1, n, 85), -10.0, np.float32)
    raw[0, :, 4] = 0.0
    raw[0, :, 5:] = 0.0
    i = 10 * 52 + 20                       # stride-8 cell (20, 10)
    raw[0, i, :4] = [0.5, 0.5, np.log(4), np.log(8)]
    raw[0, i, 4] = 1.0
    raw[0, i, 5 + 0] = 1.0                 # person
    dets = yolox_postprocess(raw, size, ratio=1.0, conf=0.5)
    assert len(dets) == 1 and dets[0]["cls"] == "person"
    b = dets[0]["box"]
    assert abs(b["x"] + b["w"] / 2 - 164) < 1e-3 and abs(b["w"] - 32) < 1e-3


class Skip(Exception):
    pass


def test_yolox_runs_on_frame():
    if not (ROOT / "models" / "yolox_nano.onnx").exists():
        raise Skip("model not downloaded; run scripts/fetch_binaries.sh")
    m = Yolox(str(ROOT / "models" / "yolox_nano.onnx"), threads=1)
    img = np.random.default_rng(0).integers(0, 255, (540, 960, 3), dtype=np.uint8)
    dets = m(img)
    assert isinstance(dets, list)


def test_tracker_keeps_ids():
    t = IouTracker()
    a = t.update(0.0, [{"x": 0, "y": 0, "w": 50, "h": 100}, {"x": 200, "y": 0, "w": 50, "h": 100}])
    b = t.update(0.1, [{"x": 205, "y": 2, "w": 50, "h": 100}, {"x": 3, "y": 1, "w": 50, "h": 100}])
    assert b == [a[1], a[0]]
    c = t.update(2.0, [{"x": 3, "y": 1, "w": 50, "h": 100}])
    assert c[0] not in a                  # aged out, new id


def test_barcode_survives_noise():
    y = np.full((540, 960), 90, np.uint8)
    barcode.stamp(y, 123456)
    noisy = np.clip(y.astype(int) + np.random.default_rng(1).normal(0, 20, y.shape), 0, 255).astype(np.uint8)
    assert barcode.read(noisy) == 123456


def test_retention_deletes_oldest_first():
    d = Path(tempfile.mkdtemp())
    idx = SegmentIndex(str(d / "s.db"))
    now = time.time()
    for i in range(5):
        p = d / f"seg{i}.mp4"
        p.write_bytes(b"x" * 1000)
        idx.opened("cam", 1, str(p), now - 1000 + i * 10)
        idx.closed(str(p), 10.0, 1000)
    gone = enforce_retention(idx, max_bytes=2500, max_age_s=1e9, now=now)
    assert [Path(g).name for g in gone] == ["seg0.mp4", "seg1.mp4", "seg2.mp4"]
    assert len(idx.all()) == 2


if __name__ == "__main__":
    fails = 0
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            try:
                fn()
                print("ok  ", name)
            except Skip as e:
                print("skip", name, e)
            except Exception as e:  # noqa: BLE001
                fails += 1
                print("FAIL", name, e)
    out = ROOT / "results" / "python_tests.json"
    out.write_text(json.dumps({"failed": fails, "total": sum(1 for n in globals() if n.startswith("test_"))}))
    raise SystemExit(1 if fails else 0)
